#include <stdio.h>
#include <stdbool.h>
#include <windows.h>

// Generate the next pandigital permutation
bool nextPermutation(int* array, int size) {
    // Find the largest index k such that array[k] < array[k + 1]
    int k = -1;
    for (int i = 0; i < size - 1; i++) {
        if (array[i] < array[i + 1]) {
            k = i;
        }
    }

    // If no such index exists, the permutation is the last one
    if (k == -1) {
        return false;
    }

    // Find the largest index l greater than k such that array[k] < array[l]
    int l = k + 1;
    for (int i = k + 2; i < size; i++) {
        if (array[k] < array[i]) {
            l = i;
        }
    }

    // Swap the values at indices k and l
    int temp = array[k];
    array[k] = array[l];
    array[l] = temp;

    // Reverse the sequence from index k + 1 to the end
    int left = k + 1;
    int right = size - 1;
    while (left < right) {
        temp = array[left];
        array[left] = array[right];
        array[right] = temp;
        left++;
        right--;
    }

    return true;
}

// Convert array of digits to a number
int arrayToNumber(int* array, int size) {
    int result = 0;
    for (int i = 0; i < size; i++) {
        result = result * 10 + array[i];
    }
    return result;
}

int main() {
    // Variables for timing
    LARGE_INTEGER frequency;
    LARGE_INTEGER start;
    LARGE_INTEGER end;
    double elapsed_time;

    // Get the frequency of the performance counter
    QueryPerformanceFrequency(&frequency);

    // Start timing
    QueryPerformanceCounter(&start);

    // Start with the smallest pandigital number: 123456789
    int digits[9] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
    int count = 1; // We're starting with the first pandigital number
    int target_count = 100000;
    int target_number = arrayToNumber(digits, 9);

    // Generate permutations until we reach the target count
    while (count < target_count && nextPermutation(digits, 9)) {
        count++;

        if (count == target_count) {
            target_number = arrayToNumber(digits, 9);
            break;
        }
    }

    // End timing
    QueryPerformanceCounter(&end);

    // Calculate elapsed time in nanoseconds
    elapsed_time = ((double)(end.QuadPart - start.QuadPart) * 1000000000.0) / frequency.QuadPart;

    // Output results
    printf("The %d-th pandigital number is: %d\n", target_count, target_number);
    printf("Execution time: %.2f nanoseconds (%.2f milliseconds)\n",
        elapsed_time, elapsed_time / 1000000.0);

    return 0;
}