use std::time::Instant;

fn has_all_digits(mut num: u64) -> bool {
    let mut digits = [false; 10];
    while num > 0 {
        let digit = (num % 10) as usize;
        if digit == 0 || digits[digit] {
            return false;
        }
        digits[digit] = true;
        num /= 10;
    }
    digits.iter().skip(1).all(|&x| x) // Ensure all digits 1-9 are present
}

fn main() {
    let start_time = Instant::now(); // Start the timer

    let mut count = 0;
    let target_position = 100_000;
    let mut result = 0;

    for num in 123_456_789u64..=987_654_321u64 {
        if has_all_digits(num) {
            count += 1;
            if count == target_position {
                result = num;
                break;
            }
        }
    }

    let duration = start_time.elapsed(); // Stop the timer

    println!("The 100,000th number in the sequence is: {}", result);
    println!("Execution time: {:.2?} seconds", duration);
}
